<?php

/* blog/blog.html.twig */
class __TwigTemplate_8ae4c2ad0ce1570503dde6d55a34d0ac64ac31ddc7a5c343ef3111a2af4d8448 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/blog.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_439bbc15d2fd4c3057f2fd9407c770a8f40d709530a9d87717494166bcf4e090 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_439bbc15d2fd4c3057f2fd9407c770a8f40d709530a9d87717494166bcf4e090->enter($__internal_439bbc15d2fd4c3057f2fd9407c770a8f40d709530a9d87717494166bcf4e090_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/blog.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_439bbc15d2fd4c3057f2fd9407c770a8f40d709530a9d87717494166bcf4e090->leave($__internal_439bbc15d2fd4c3057f2fd9407c770a8f40d709530a9d87717494166bcf4e090_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_75ad1730f07341e5e14bcb32aa1f611e81adb4a13e98d01260ecc73c986922c3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_75ad1730f07341e5e14bcb32aa1f611e81adb4a13e98d01260ecc73c986922c3->enter($__internal_75ad1730f07341e5e14bcb32aa1f611e81adb4a13e98d01260ecc73c986922c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "blog/blog.html.twig"));

        echo "Genus ";
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
        
        $__internal_75ad1730f07341e5e14bcb32aa1f611e81adb4a13e98d01260ecc73c986922c3->leave($__internal_75ad1730f07341e5e14bcb32aa1f611e81adb4a13e98d01260ecc73c986922c3_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_ad385046da3d4289c03a3f4fb942542c3386ea2ab236a4534e36900f07c37a16 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad385046da3d4289c03a3f4fb942542c3386ea2ab236a4534e36900f07c37a16->enter($__internal_ad385046da3d4289c03a3f4fb942542c3386ea2ab236a4534e36900f07c37a16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "blog/blog.html.twig"));

        // line 6
        echo "    <h2 class=\"genus-name\">";
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
        echo "</h2>
    <div class=\"sea-creature-container\">
        <div class=\"genus-photo\"></div>
        <div class=\"genus-details\">
            <dl class=\"genus-details-list\">
                <dt>Subfamily:</dt>
                <dd>Octopodinae</dd>
                <dt>Known Species:</dt>
                <dd>289</dd>
                <dt>Fun Fact:</dt>
                <dd>Octopuses can change the color of their body in just three-tenths of a second!</dd>
            </dl>
        </div>
    </div>
    <div id=\"test\"></div>
";
        
        $__internal_ad385046da3d4289c03a3f4fb942542c3386ea2ab236a4534e36900f07c37a16->leave($__internal_ad385046da3d4289c03a3f4fb942542c3386ea2ab236a4534e36900f07c37a16_prof);

    }

    // line 22
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_e33bf5dd88ba6bc44cebec6ebc44e5b9198d14cdd7ee0b23b36e761ba633f34b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e33bf5dd88ba6bc44cebec6ebc44e5b9198d14cdd7ee0b23b36e761ba633f34b->enter($__internal_e33bf5dd88ba6bc44cebec6ebc44e5b9198d14cdd7ee0b23b36e761ba633f34b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "blog/blog.html.twig"));

        // line 23
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/react/0.14.3/react.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/react/0.14.3/react-dom.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/babel-core/5.8.23/browser.min.js\"></script>
    <script type=\"text/babel\" src=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/notes.react.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/babel\">

        var notesurl = '";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_show_comments", array("var" => (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")))), "html", null, true);
        echo "';
        ReactDOM.render(<NoteSection url={notesurl} />,document.getElementById(\"test\"));

    </script>
";
        
        $__internal_e33bf5dd88ba6bc44cebec6ebc44e5b9198d14cdd7ee0b23b36e761ba633f34b->leave($__internal_e33bf5dd88ba6bc44cebec6ebc44e5b9198d14cdd7ee0b23b36e761ba633f34b_prof);

    }

    public function getTemplateName()
    {
        return "blog/blog.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 30,  93 => 27,  85 => 23,  79 => 22,  55 => 6,  49 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}Genus {{ name }}{% endblock %}

{% block body %}
    <h2 class=\"genus-name\">{{ name }}</h2>
    <div class=\"sea-creature-container\">
        <div class=\"genus-photo\"></div>
        <div class=\"genus-details\">
            <dl class=\"genus-details-list\">
                <dt>Subfamily:</dt>
                <dd>Octopodinae</dd>
                <dt>Known Species:</dt>
                <dd>289</dd>
                <dt>Fun Fact:</dt>
                <dd>Octopuses can change the color of their body in just three-tenths of a second!</dd>
            </dl>
        </div>
    </div>
    <div id=\"test\"></div>
{% endblock %}
{% block javascripts %}
    {{ parent() }}
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/react/0.14.3/react.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/react/0.14.3/react-dom.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/babel-core/5.8.23/browser.min.js\"></script>
    <script type=\"text/babel\" src=\"{{ asset('js/notes.react.js') }}\"></script>
    <script type=\"text/babel\">

        var notesurl = '{{ path('blog_show_comments', {'var' : name}) }}';
        ReactDOM.render(<NoteSection url={notesurl} />,document.getElementById(\"test\"));

    </script>
{% endblock %}
", "blog/blog.html.twig", "C:\\Users\\Mohamed\\symfonyDev\\MonBlogSym\\app\\Resources\\views\\blog\\blog.html.twig");
    }
}
