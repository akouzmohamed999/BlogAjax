<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_4001195bf2c5a116cb1700173c8c3a2fb6de277e4e89b1d2c6d3b30afe714169 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_025878e54af14575b61736a1de5bac4984e1f518f3f521c9d0c190b633328633 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_025878e54af14575b61736a1de5bac4984e1f518f3f521c9d0c190b633328633->enter($__internal_025878e54af14575b61736a1de5bac4984e1f518f3f521c9d0c190b633328633_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_025878e54af14575b61736a1de5bac4984e1f518f3f521c9d0c190b633328633->leave($__internal_025878e54af14575b61736a1de5bac4984e1f518f3f521c9d0c190b633328633_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_1161497aaf33df6cad01f499c4fee5e0722b5ab26c63f24bf8fe3bb602aa48bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1161497aaf33df6cad01f499c4fee5e0722b5ab26c63f24bf8fe3bb602aa48bd->enter($__internal_1161497aaf33df6cad01f499c4fee5e0722b5ab26c63f24bf8fe3bb602aa48bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Collector/router.html.twig"));

        
        $__internal_1161497aaf33df6cad01f499c4fee5e0722b5ab26c63f24bf8fe3bb602aa48bd->leave($__internal_1161497aaf33df6cad01f499c4fee5e0722b5ab26c63f24bf8fe3bb602aa48bd_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_9b10d8d152c82185a80415791fd43ac17eeca93788e584b62e2fb46bfe2994be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9b10d8d152c82185a80415791fd43ac17eeca93788e584b62e2fb46bfe2994be->enter($__internal_9b10d8d152c82185a80415791fd43ac17eeca93788e584b62e2fb46bfe2994be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Collector/router.html.twig"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_9b10d8d152c82185a80415791fd43ac17eeca93788e584b62e2fb46bfe2994be->leave($__internal_9b10d8d152c82185a80415791fd43ac17eeca93788e584b62e2fb46bfe2994be_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_66cd0b479444cb64063f60b64a3afb681ee10e2ebe085ee202d5f54f7fa44c6d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66cd0b479444cb64063f60b64a3afb681ee10e2ebe085ee202d5f54f7fa44c6d->enter($__internal_66cd0b479444cb64063f60b64a3afb681ee10e2ebe085ee202d5f54f7fa44c6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Collector/router.html.twig"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_66cd0b479444cb64063f60b64a3afb681ee10e2ebe085ee202d5f54f7fa44c6d->leave($__internal_66cd0b479444cb64063f60b64a3afb681ee10e2ebe085ee202d5f54f7fa44c6d_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\Users\\Mohamed\\symfonyDev\\MonBlogSym\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
