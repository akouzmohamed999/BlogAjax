<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_bca5cf6ddf11805bd8741336323808617737f8a05dc22bd4155eb567850a4f52 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f5f7c290beed16457c413f94a51a663f8b996733b5733cc7501b88e51c7e5573 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f5f7c290beed16457c413f94a51a663f8b996733b5733cc7501b88e51c7e5573->enter($__internal_f5f7c290beed16457c413f94a51a663f8b996733b5733cc7501b88e51c7e5573_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_f5f7c290beed16457c413f94a51a663f8b996733b5733cc7501b88e51c7e5573->leave($__internal_f5f7c290beed16457c413f94a51a663f8b996733b5733cc7501b88e51c7e5573_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
", "@Framework/Form/number_widget.html.php", "C:\\Users\\Mohamed\\symfonyDev\\MonBlogSym\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\number_widget.html.php");
    }
}
