<?php

/* @Twig/Exception/exception.atom.twig */
class __TwigTemplate_32519324fd6afb10f8add6b32e4d85e7e9256c3d349ff6568d3268c095ff710c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8f00b88b871b6764f51a162a5c7134dffc60f1e7ad63986f1ab477a7b13b9406 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8f00b88b871b6764f51a162a5c7134dffc60f1e7ad63986f1ab477a7b13b9406->enter($__internal_8f00b88b871b6764f51a162a5c7134dffc60f1e7ad63986f1ab477a7b13b9406_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "@Twig/Exception/exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_8f00b88b871b6764f51a162a5c7134dffc60f1e7ad63986f1ab477a7b13b9406->leave($__internal_8f00b88b871b6764f51a162a5c7134dffc60f1e7ad63986f1ab477a7b13b9406_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "@Twig/Exception/exception.atom.twig", "C:\\Users\\Mohamed\\symfonyDev\\MonBlogSym\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.atom.twig");
    }
}
