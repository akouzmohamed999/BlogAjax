<?php

/* blog/blog.html.twig */
class __TwigTemplate_06e27db6fbcf2ca23de74756cd797bc5a302de0e9c07016c5ef9a704d8fb1f29 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/blog.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_776a162ebc1026add78745eb328a6ec4f52826fb70fa4aafe249abc72502541c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_776a162ebc1026add78745eb328a6ec4f52826fb70fa4aafe249abc72502541c->enter($__internal_776a162ebc1026add78745eb328a6ec4f52826fb70fa4aafe249abc72502541c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/blog.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_776a162ebc1026add78745eb328a6ec4f52826fb70fa4aafe249abc72502541c->leave($__internal_776a162ebc1026add78745eb328a6ec4f52826fb70fa4aafe249abc72502541c_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_89ad496325ca1b22bf1f538f14a9786b590ac96c14eee6e9b33762d6ecaec2ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89ad496325ca1b22bf1f538f14a9786b590ac96c14eee6e9b33762d6ecaec2ed->enter($__internal_89ad496325ca1b22bf1f538f14a9786b590ac96c14eee6e9b33762d6ecaec2ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "blog/blog.html.twig"));

        echo "Genus ";
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
        
        $__internal_89ad496325ca1b22bf1f538f14a9786b590ac96c14eee6e9b33762d6ecaec2ed->leave($__internal_89ad496325ca1b22bf1f538f14a9786b590ac96c14eee6e9b33762d6ecaec2ed_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_dffd9525e9b17d3de75de166346a3c5d604df178078c33f86e8b1a7264b17a52 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dffd9525e9b17d3de75de166346a3c5d604df178078c33f86e8b1a7264b17a52->enter($__internal_dffd9525e9b17d3de75de166346a3c5d604df178078c33f86e8b1a7264b17a52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "blog/blog.html.twig"));

        // line 6
        echo "    <h2 class=\"genus-name\">";
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
        echo "</h2>
    <div class=\"sea-creature-container\">
        <div class=\"genus-photo\"></div>
        <div class=\"genus-details\">
            <dl class=\"genus-details-list\">
                <dt>Subfamily:</dt>
                <dd>Octopodinae</dd>
                <dt>Known Species:</dt>
                <dd>289</dd>
                <dt>Fun Fact:</dt>
                <dd>Octopuses can change the color of their body in just three-tenths of a second!</dd>
            </dl>
        </div>
    </div>
    <div id=\"test\"></div>
";
        
        $__internal_dffd9525e9b17d3de75de166346a3c5d604df178078c33f86e8b1a7264b17a52->leave($__internal_dffd9525e9b17d3de75de166346a3c5d604df178078c33f86e8b1a7264b17a52_prof);

    }

    // line 22
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_450618667be314c56d2e53c7b239703d5273c60a239b91ae44631b29b58ba34b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_450618667be314c56d2e53c7b239703d5273c60a239b91ae44631b29b58ba34b->enter($__internal_450618667be314c56d2e53c7b239703d5273c60a239b91ae44631b29b58ba34b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "blog/blog.html.twig"));

        // line 23
        echo "    ";
        $this->displayParentBlock("javascript", $context, $blocks);
        echo "
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/react/0.14.3/react.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/react/0.14.3/react-dom.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/babel-core/5.8.23/browser.min.js\"></script>
    <script type=\"text/babel\" src='js/notes.react.js'></script>
    <script type=\"text/babel\">

        var notesurl = '";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_show_comments", array("var" => (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")))), "html", null, true);
        echo "';
        ReactDOM.render(<NoteSection url={notesurl} />,document.getElementById(\"test\"));

    </script>
";
        
        $__internal_450618667be314c56d2e53c7b239703d5273c60a239b91ae44631b29b58ba34b->leave($__internal_450618667be314c56d2e53c7b239703d5273c60a239b91ae44631b29b58ba34b_prof);

    }

    public function getTemplateName()
    {
        return "blog/blog.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 30,  85 => 23,  79 => 22,  55 => 6,  49 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}Genus {{ name }}{% endblock %}

{% block body %}
    <h2 class=\"genus-name\">{{ name }}</h2>
    <div class=\"sea-creature-container\">
        <div class=\"genus-photo\"></div>
        <div class=\"genus-details\">
            <dl class=\"genus-details-list\">
                <dt>Subfamily:</dt>
                <dd>Octopodinae</dd>
                <dt>Known Species:</dt>
                <dd>289</dd>
                <dt>Fun Fact:</dt>
                <dd>Octopuses can change the color of their body in just three-tenths of a second!</dd>
            </dl>
        </div>
    </div>
    <div id=\"test\"></div>
{% endblock %}
{% block javascript %}
    {{ parent() }}
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/react/0.14.3/react.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/react/0.14.3/react-dom.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/babel-core/5.8.23/browser.min.js\"></script>
    <script type=\"text/babel\" src='js/notes.react.js'></script>
    <script type=\"text/babel\">

        var notesurl = '{{ path('blog_show_comments', {'var' : name}) }}';
        ReactDOM.render(<NoteSection url={notesurl} />,document.getElementById(\"test\"));

    </script>
{% endblock %}
", "blog/blog.html.twig", "C:\\Users\\Mohamed\\symfonyDev\\MonBlogSym\\app\\Resources\\views\\blog\\blog.html.twig");
    }
}
