<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_979ca137f71a78c20134592840f9d6faffc6190d8cc0435d8436345198a7d34d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7a73d3e85a0f6b1b9ac6b1bf4e1b09e3a00a0175a5f0ee9b6185bfef5e1c7a02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7a73d3e85a0f6b1b9ac6b1bf4e1b09e3a00a0175a5f0ee9b6185bfef5e1c7a02->enter($__internal_7a73d3e85a0f6b1b9ac6b1bf4e1b09e3a00a0175a5f0ee9b6185bfef5e1c7a02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_7a73d3e85a0f6b1b9ac6b1bf4e1b09e3a00a0175a5f0ee9b6185bfef5e1c7a02->leave($__internal_7a73d3e85a0f6b1b9ac6b1bf4e1b09e3a00a0175a5f0ee9b6185bfef5e1c7a02_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_53c6f563b1a78a17e44a5d151da9e2e20ead01c705d059030956cbe4c63f77a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_53c6f563b1a78a17e44a5d151da9e2e20ead01c705d059030956cbe4c63f77a0->enter($__internal_53c6f563b1a78a17e44a5d151da9e2e20ead01c705d059030956cbe4c63f77a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        echo "";
        
        $__internal_53c6f563b1a78a17e44a5d151da9e2e20ead01c705d059030956cbe4c63f77a0->leave($__internal_53c6f563b1a78a17e44a5d151da9e2e20ead01c705d059030956cbe4c63f77a0_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\Users\\Mohamed\\symfonyDev\\MonBlogSym\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
