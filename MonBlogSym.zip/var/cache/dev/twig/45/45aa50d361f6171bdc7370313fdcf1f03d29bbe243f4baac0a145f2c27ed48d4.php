<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_95a0c728547f34059540c5b2d5ddfcbed561bde92e382f6239117c982e601249 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_27b283db3974c8423047c5eafb3889403e2d40b59291a3b3c6511571b18cb290 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_27b283db3974c8423047c5eafb3889403e2d40b59291a3b3c6511571b18cb290->enter($__internal_27b283db3974c8423047c5eafb3889403e2d40b59291a3b3c6511571b18cb290_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_27b283db3974c8423047c5eafb3889403e2d40b59291a3b3c6511571b18cb290->leave($__internal_27b283db3974c8423047c5eafb3889403e2d40b59291a3b3c6511571b18cb290_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_89fc86223c4689e407a60485d5bee373326766471ef5a7ce6046ce5855eeeecf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89fc86223c4689e407a60485d5bee373326766471ef5a7ce6046ce5855eeeecf->enter($__internal_89fc86223c4689e407a60485d5bee373326766471ef5a7ce6046ce5855eeeecf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        echo "";
        
        $__internal_89fc86223c4689e407a60485d5bee373326766471ef5a7ce6046ce5855eeeecf->leave($__internal_89fc86223c4689e407a60485d5bee373326766471ef5a7ce6046ce5855eeeecf_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "C:\\Users\\Mohamed\\symfonyDev\\MonBlogSym\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
