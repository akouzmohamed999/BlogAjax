<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_c5124d29358a8bddac148f6439182c910adde20946404dc46bb5deef8b0a3916 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8e4a17a5dcafbad5ced86bdc8fa0088abcb66442bb6956138badeff5fa98c9b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8e4a17a5dcafbad5ced86bdc8fa0088abcb66442bb6956138badeff5fa98c9b1->enter($__internal_8e4a17a5dcafbad5ced86bdc8fa0088abcb66442bb6956138badeff5fa98c9b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_8e4a17a5dcafbad5ced86bdc8fa0088abcb66442bb6956138badeff5fa98c9b1->leave($__internal_8e4a17a5dcafbad5ced86bdc8fa0088abcb66442bb6956138badeff5fa98c9b1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "C:\\Users\\Mohamed\\symfonyDev\\MonBlogSym\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\textarea_widget.html.php");
    }
}
