<?php

/* :blog:blog.html.twig */
class __TwigTemplate_edd792fe776fa60665232628112367b497bc1a7d147c79e3507699717f142903 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":blog:blog.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ed74c00bef30318665e557ae65256dd9fad7253177aeffd9a663ec9bdc365ee1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed74c00bef30318665e557ae65256dd9fad7253177aeffd9a663ec9bdc365ee1->enter($__internal_ed74c00bef30318665e557ae65256dd9fad7253177aeffd9a663ec9bdc365ee1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:blog.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ed74c00bef30318665e557ae65256dd9fad7253177aeffd9a663ec9bdc365ee1->leave($__internal_ed74c00bef30318665e557ae65256dd9fad7253177aeffd9a663ec9bdc365ee1_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_70b38107df75e4d1c14296f4a1cab06aa2c46a346aa24f89f017e2d409d7cc5d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_70b38107df75e4d1c14296f4a1cab06aa2c46a346aa24f89f017e2d409d7cc5d->enter($__internal_70b38107df75e4d1c14296f4a1cab06aa2c46a346aa24f89f017e2d409d7cc5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", ":blog:blog.html.twig"));

        echo "Genus ";
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
        
        $__internal_70b38107df75e4d1c14296f4a1cab06aa2c46a346aa24f89f017e2d409d7cc5d->leave($__internal_70b38107df75e4d1c14296f4a1cab06aa2c46a346aa24f89f017e2d409d7cc5d_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_9b74aada0e0dc8c7bb1c484852f13f3d7b7690c5ed757fbefe17cd72b51e039f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9b74aada0e0dc8c7bb1c484852f13f3d7b7690c5ed757fbefe17cd72b51e039f->enter($__internal_9b74aada0e0dc8c7bb1c484852f13f3d7b7690c5ed757fbefe17cd72b51e039f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", ":blog:blog.html.twig"));

        // line 6
        echo "    <h2 class=\"genus-name\">";
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
        echo "</h2>
    <div class=\"sea-creature-container\">
        <div class=\"genus-photo\"></div>
        <div class=\"genus-details\">
            <dl class=\"genus-details-list\">
                <dt>Subfamily:</dt>
                <dd>Octopodinae</dd>
                <dt>Known Species:</dt>
                <dd>289</dd>
                <dt>Fun Fact:</dt>
                <dd>Octopuses can change the color of their body in just three-tenths of a second!</dd>
            </dl>
        </div>
    </div>
    <div id=\"test\"></div>
";
        
        $__internal_9b74aada0e0dc8c7bb1c484852f13f3d7b7690c5ed757fbefe17cd72b51e039f->leave($__internal_9b74aada0e0dc8c7bb1c484852f13f3d7b7690c5ed757fbefe17cd72b51e039f_prof);

    }

    // line 22
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_5011452ba6dd225666fced42cd3ac34acf294ab63e6d228f8ca118472d1f09ac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5011452ba6dd225666fced42cd3ac34acf294ab63e6d228f8ca118472d1f09ac->enter($__internal_5011452ba6dd225666fced42cd3ac34acf294ab63e6d228f8ca118472d1f09ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", ":blog:blog.html.twig"));

        // line 23
        echo "    ";
        $this->displayParentBlock("javascript", $context, $blocks);
        echo "
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/react/0.14.3/react.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/react/0.14.3/react-dom.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/babel-core/5.8.23/browser.min.js\"></script>
    <script type=\"text/babel\" src='js/notes.react.js'></script>
    <script type=\"text/babel\">

        var notesurl = '";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_show_comments", array("var" => (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")))), "html", null, true);
        echo "';
        ReactDOM.render(<NoteSection url={notesurl} />,document.getElementById(\"test\"));

    </script>
";
        
        $__internal_5011452ba6dd225666fced42cd3ac34acf294ab63e6d228f8ca118472d1f09ac->leave($__internal_5011452ba6dd225666fced42cd3ac34acf294ab63e6d228f8ca118472d1f09ac_prof);

    }

    public function getTemplateName()
    {
        return ":blog:blog.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 30,  85 => 23,  79 => 22,  55 => 6,  49 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}Genus {{ name }}{% endblock %}

{% block body %}
    <h2 class=\"genus-name\">{{ name }}</h2>
    <div class=\"sea-creature-container\">
        <div class=\"genus-photo\"></div>
        <div class=\"genus-details\">
            <dl class=\"genus-details-list\">
                <dt>Subfamily:</dt>
                <dd>Octopodinae</dd>
                <dt>Known Species:</dt>
                <dd>289</dd>
                <dt>Fun Fact:</dt>
                <dd>Octopuses can change the color of their body in just three-tenths of a second!</dd>
            </dl>
        </div>
    </div>
    <div id=\"test\"></div>
{% endblock %}
{% block javascript %}
    {{ parent() }}
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/react/0.14.3/react.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/react/0.14.3/react-dom.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/babel-core/5.8.23/browser.min.js\"></script>
    <script type=\"text/babel\" src='js/notes.react.js'></script>
    <script type=\"text/babel\">

        var notesurl = '{{ path('blog_show_comments', {'var' : name}) }}';
        ReactDOM.render(<NoteSection url={notesurl} />,document.getElementById(\"test\"));

    </script>
{% endblock %}
", ":blog:blog.html.twig", "C:\\Users\\Mohamed\\symfonyDev\\MonBlogSym\\app/Resources\\views/blog/blog.html.twig");
    }
}
