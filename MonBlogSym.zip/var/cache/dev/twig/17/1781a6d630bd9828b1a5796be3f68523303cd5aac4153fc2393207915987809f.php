<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_63cc715ae2e9ed540f81712b5b444f574c09431396b1baf0560e1f5c721ab666 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_752f304dc54f7abd53f6227b41baafab9c2ea540f393181b7cea3e09bf1dd1ac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_752f304dc54f7abd53f6227b41baafab9c2ea540f393181b7cea3e09bf1dd1ac->enter($__internal_752f304dc54f7abd53f6227b41baafab9c2ea540f393181b7cea3e09bf1dd1ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_752f304dc54f7abd53f6227b41baafab9c2ea540f393181b7cea3e09bf1dd1ac->leave($__internal_752f304dc54f7abd53f6227b41baafab9c2ea540f393181b7cea3e09bf1dd1ac_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "C:\\Users\\Mohamed\\symfonyDev\\MonBlogSym\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_row.html.php");
    }
}
